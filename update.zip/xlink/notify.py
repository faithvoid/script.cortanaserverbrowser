import xbmc
import xbmcgui
import time
import urllib2
import xml.etree.ElementTree as ET
import re
from collections import deque
import os

# Queue for storing notification messages
notification_queue = deque()

def clear_notifications_file():
    """ Clear the notifications file at the start of the script. """
    open("Q:\\scripts\\Cortana Server Browser\\XLink\\notifications.txt", "w").close()

# Load previous notifications from file
def load_notifications():
    if os.path.exists("Q:\\scripts\\Cortana Server Browser\\XLink\\notifications.txt"):
        with open("Q:\\scripts\\Cortana Server Browser\\XLink\\notifications.txt", "r") as f:
            return set(f.read().strip().split("\n"))
    return set()

# Save current notifications to file
def save_notifications(notifications):
    with open("Q:\\scripts\\Cortana Server Browser\\XLink\\notifications.txt", "w") as f:
        for notification in notifications:
            f.write("%s\n" % notification)

def check_rss():
    current_notifications = load_notifications()
    new_notifications = set()
    try:
        url = 'https://ogxbox.org/rss/xlinkkai'
        req = urllib2.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:101.0) Gecko/20100101 Firefox/101.0'})
        response = urllib2.urlopen(req)
        data = response.read()
        root = ET.fromstring(data)

        for item in root.findall('.//item'):
            title = item.find('title').text
            # Check if title includes "0 in 0 sessions" and skip if it does
            if "(0 in 0 sessions)" in title:
                continue
            match = re.search(r'(\d+) players?', title)  # Look for number of players
            if match:
                players = int(match.group(1))
                if players > 0:  # Only check if players are more than 0
                    new_notifications.add(title)
                    if title not in current_notifications:
                        notification_queue.append((title, 5000, True))
    except Exception as e:
        error_msg = "RSS Error: " + str(e)
        notification_queue.append((error_msg, 5000, False))
        new_notifications.add(error_msg)
    
    save_notifications(new_notifications)


def process_notifications():
    while notification_queue:
        message, duration, should_scroll = notification_queue.popleft()
        extended_duration = duration if not message.endswith(')') else duration + 2500
        if should_scroll:
            scroll_notification(message, extended_duration)
        else:
            xbmc.executebuiltin('Notification("Found XLink Session(s)!", "{}", {})'.format(message, extended_duration))
            time.sleep(extended_duration / 1000.0)

def scroll_notification(message, duration):
    chunk_size = 32
    length = len(message)
    if length <= chunk_size:
        xbmc.executebuiltin('Notification("Found XLink Session(s)!", "{}", {})'.format(message, duration))
        time.sleep(duration / 1000.0)
    else:
        step_size = 2
        step_duration = 1000
        total_steps = (length - chunk_size + step_size) // step_size if length > chunk_size else 1
        
        for i in range(0, total_steps):
            start_index = i * step_size
            end_index = start_index + chunk_size
            current_chunk = message[start_index:end_index]
            xbmc.executebuiltin('Notification("Found XLink Session(s)!", "{}", {})'.format(current_chunk, step_duration))
            time.sleep(step_duration / 1000.0)
        
        # Extend the display time if the message ends with ")"
        last_chunk_duration = 2500 if message.endswith(')') else 1000
        xbmc.executebuiltin('Notification("Found XLink Session(s)!", "{}", {})'.format(message[-chunk_size:], last_chunk_duration))
        time.sleep(last_chunk_duration / 1000.0)

# Clear notifications file at the start
clear_notifications_file()

while True:
    check_rss()
    process_notifications()
    time.sleep(60)
