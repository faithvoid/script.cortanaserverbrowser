import xbmcgui
import socket

def check_connection():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5)  # Timeout for the connection attempt

    try:
        sock.connect(("8.8.8.8", 53))  # Port 53 is used for DNS
        sock.close()
        return True
    except socket.error as e:
        return False

def main():
    dialog = xbmcgui.Dialog()
    if check_connection():
        dialog.ok("Internet Connection Status", "Connection Success! Your Xbox is connected to the internet!")
	xbmc.executebuiltin('RunScript(Q:\\scripts\\Cortana Server Browser\\settings\\settings.py)')
    else:
        dialog.ok("Internet Connection Status", "Connection Failed! Your Xbox is not connected to the internet, check your cables and network settings and try again.")
	xbmc.executebuiltin('RunScript(Q:\\scripts\\Cortana Server Browser\\settings\\settings.py)')

if __name__ == "__main__":
    main()