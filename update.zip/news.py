import xbmc
import xbmcgui
import xml.etree.ElementTree as ET
import urllib2
import textwrap

def fetch_and_parse_rss(url):
    try:
        request = urllib2.Request(url)
        request.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3')
        request.add_header('Referer', 'http://www.google.com')
        
        response = urllib2.urlopen(request)
        data = response.read().decode('utf-8')
        root = ET.fromstring(data.encode('utf-8'))
        return root
    except urllib2.HTTPError as e:
        xbmc.log("HTTP Error: {}".format(e.code), xbmc.LOGERROR)
        return None
    except urllib2.URLError as e:
        xbmc.log("URL Error: {}".format(e.reason), xbmc.LOGERROR)
        return None
    except Exception as e:
        xbmc.log("Failed to fetch or parse the feed: {}".format(str(e)), xbmc.LOGERROR)
        return None

def wrap_text(text, width=64):
    wrapped_lines = textwrap.wrap(text, width)
    return '\n'.join(wrapped_lines)

def show_news_articles():
    dialog = xbmcgui.Dialog()
    news_menu = [
        ("Insignia", "http://bsky.app/profile/insignia.live"),
        ("XLink Kai", "http://bsky.app/profile/did:plc:w72idvo677kghtpacp52gw4o/rss"),
        ("Xbox-Scene", "http://feeds.feedburner.com/XboxScene"),
    ]

    titles = [item[0] for item in news_menu]
    selected = dialog.select("Cortana News", titles)

    if selected >= 0:
        _, url = news_menu[selected]
        root = fetch_and_parse_rss(url)
        if root:
            display_news_items(dialog, root)

def display_news_items(dialog, root):
    channel = root.find('channel')
    if not channel:
        xbmc.log("No channel element found in the feed", xbmc.LOGERROR)
        return

    items = []
    descriptions = []
    for item in channel.findall('item'):
        title = item.find('title').text if item.find('title') is not None else "No Title"
        description = item.find('description').text if item.find('description') is not None else "No Description"
        items.append(title)
        descriptions.append(wrap_text(description))

    selected = dialog.select("Select an article to read:", items)
    if selected >= 0:
        dialog.ok(items[selected], descriptions[selected])

if __name__ == '__main__':
    show_news_articles()
